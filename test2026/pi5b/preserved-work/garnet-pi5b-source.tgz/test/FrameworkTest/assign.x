# SPDX-FileCopyrightText: 2024-2026 CantorAI Inc.
# SPDX-License-Identifier: Apache-2.0

t1 = tensor([[1,2,3],[4,5,6],[7,8,9],[10,11,12]])
d = dict()
i = 100
d["t2_${i}"] = tensor([[10,20,30,40],[50,60,70,80],[90,100,110,120]])

print("Done")