"""Load validated TP2 prepacked engines sequentially, without GPU inference.

Host Python: GARNET_REFERENCE NEW_DIRECTORY.
Requires the opt-in TensorRT11 memory diagnostic in the built Garnet library.
Reported weight/context bytes are engine statistics, not allocation peaks.
"""
import json
import os
from pathlib import Path
import argparse
import re
import subprocess
import sys

repo = Path(__file__).resolve().parents[2]
root = Path(os.environ.get('CANTORAI_ROOT', repo.parent))
from resident_budget import (native_identity, hardware_identity, kernel_environment,
                             checkpoint_identity, plan_identity, file_sha256)
from engine_profile_shape import candidate_shape, validate_candidate_shape
from resident_runtime_scheduling import POLICY as runtime_switch_policy, parse_switch_us

if len(sys.argv) in (4,5) and sys.argv[1] == '--runtime':
    import garnet as G
    from pipeline import make_tensor_parallel_plan, build_tensor_parallel
    from garnet_pipeline import ResidentTensorParallel
    reference_path, output = map(Path, sys.argv[2:4])
    reference_bytes = reference_path.read_bytes()
    reference = json.loads(reference_bytes)
    specification = (validate_candidate_shape(json.loads(Path(sys.argv[4]).read_text()),
        reference, reference_bytes) if len(sys.argv) == 5 else None)
    shape = specification or reference
    if output.exists():
        raise FileExistsError(output)
    weights = Path(os.environ.get('GARNET_GPT_OSS_WEIGHTS', root / 'models/gpt-oss-120b/original'))
    cache = Path(os.environ.get('GARNET_GPT_OSS_CACHE', root / 'work/gpt-oss-tp-cache'))
    devices = json.loads(G.cuda_devices_json())[:2]
    plan = make_tensor_parallel_plan(weights, devices, batch=shape['batch'],
        capacity=shape['max_context_tokens_per_request'],
        tokens=min(shape['prefill_chunk_tokens'] or shape['input_tokens_per_request'],
                   shape['input_tokens_per_request']))
    if not plan['marlin_prepacked']:
        raise ValueError('Resident budget probe requires validated prepacked constants')
    if plan['hardware'] != reference['hardware']:
        raise ValueError('Recorded and current hardware differ; regenerate the profile')
    model = None
    kv = None
    samples = []
    def memory():
        values = subprocess.check_output(['nvidia-smi', '--query-gpu=memory.used',
                    '--format=csv,noheader,nounits'], text=True)
        return [int(value.strip()) for value in values.splitlines()]
    try:
        for prefill in (True, False):
            before = memory()
            model = build_tensor_parallel(weights, cache, plan,
                plan['max_tokens'] if prefill else 1, prefill, kv,
                last_token_logits=prefill,
                padded_prefill=prefill and os.environ.get('GARNET_RESIDENT_PADDED_PREFILL') == '1')
            after = memory()
            samples.append(dict(phase='prefill' if prefill else 'decode',
                                memory_before_mib=before, memory_after_load_mib=after))
            kv = ResidentTensorParallel.shared_rank_resources(model)
            model.release()
            model = None
    finally:
        if model is not None:
            model.release()
    build = Path(os.environ.get('GARNET_BUILD_DIR', root / 'out/build/gpt-oss'))
    output.write_text(json.dumps(dict(plan=plan, phases=samples,
        resident_profile_schema=1, plan_identity=plan_identity(plan),
        native_binaries=native_identity(build), hardware_csv=hardware_identity(),
        kernel_environment=kernel_environment(), checkpoint=checkpoint_identity(weights),
        cache_root=str(cache.resolve()), padded_prefill=os.environ.get('GARNET_RESIDENT_PADDED_PREFILL') == '1',
        candidate_shape=specification,
        measurement='Sequential engine loads only; no inference or paired residency',
        limits='Sampled process memory and engine/context bounds do not include all execution peaks'), indent=2))
    sys.exit(0)

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('reference', type=Path)
parser.add_argument('directory', type=Path)
parser.add_argument('--padded-prefill', action='store_true')
parser.add_argument('--batch', type=int, help='explicit UNVALIDATED candidate batch, up to512')
parser.add_argument('--output', type=int, help='explicit UNVALIDATED fixed output reservation, up to2048')
parser.add_argument('--context', type=int, help='explicit context; must preserve input plus output')
parser.add_argument('--prefill-chunk', type=int, help='explicit UNVALIDATED prefill query chunk')
parser.add_argument('--prepacked-candidate', action='store_true',
    help='explicitly profile packed engines for a completed original-layout workload; no quality claim')
parser.add_argument('--large-prefill-block', type=int, choices=(0,64),
    help='explicit OPT42 large-prefill tile override; not a validated model result')
parser.add_argument('--prefill-ctas', type=int, choices=(1,2,4))
parser.add_argument('--prefill-up-ctas', type=int, choices=(1,2,4),
    help='explicit prefill up-projection CTA/SM override; defaults to the matched general prefill setting')
parser.add_argument('--prefill-up-stages', type=int, choices=(2,4),
    help='explicit large-prefill up-projection async stages; requires the large-prefill64 path')
parser.add_argument('--decode-ctas', type=int, choices=(1,2),
    help='explicit decode scheduling candidate; requires an explicit prefill CTA count and separate correctness gates')
parser.add_argument('--prefill-down-k', type=int, choices=(64,128),
    help='explicit OPT43 large-prefill down-projection K tile; no quality claim')
parser.add_argument('--prefill-down-ctas', type=int, choices=(1,2,4))
parser.add_argument('--direct-max-batch', type=int, choices=(128,256,512))
parser.add_argument('--direct-ctas', type=int, choices=(2,4,8,16,32))
parser.add_argument('--bf16-decode-allreduce', type=int, choices=(0,1),
    help='explicit V10 eligible decode transport candidate; requires separate correctness gates')
parser.add_argument('--bounded-prefill', type=int, choices=(0,1),
    help='explicit V11 token-local bounded MoE candidate; native calls stay<=4096rows')
parser.add_argument('--decode-router-tensorcore', type=int, choices=(0,1),
    help='explicit OPT49 BF16 tensor-core decode-router candidate; requires separate quality gates')
parser.add_argument('--tensor-router-warps', type=int, choices=(2,4),
    help='explicit exact-arithmetic tensor-core router geometry candidate; requires separate quality gates')
parser.add_argument('--prefill-gqa-query-tile', type=int, choices=(2,4),
    help='explicit shared-query GQA attention tile; requires recorded tiled head64 prefill')
parser.add_argument('--hybrid-kv', type=int, choices=(0,1),
    help='explicit OPT50 full-history/window-bank candidate; GPU quality must be proved separately')
parser.add_argument('--fast-host-pack', type=int, choices=(0,1),
    help='explicit OPT58 CPU packing candidate; target cold/refit verification remains required')
parser.add_argument('--bf16-peer-group', type=int, choices=(0,1), help='explicit owned native resource candidate; requires full correctness gates')
parser.add_argument('--bf16-peer-group-ctas', type=int, choices=(64,128,188),
    help='explicit owned BF16 peer-reduction grid candidate; requires peer group and fresh correctness/profile gates')
parser.add_argument('--bf16-peer-group-threads', type=int, choices=(256,512),
    help='explicit owned BF16 peer-reduction threads-per-CTA candidate; requires peer group and fresh correctness/profile gates')
parser.add_argument('--bf16-peer-grid-signals', type=int, choices=(0,1),
    help='explicit cooperative-grid handshake candidate; requires owned peer group and fresh correctness/profile gates')
parser.add_argument('--fused-moe-tp-reduce', type=int, choices=(0,1),
    help='explicit OPT135 MoE direct-BF16 composite prefill candidate; requires the owned peer group')
parser.add_argument('--sync-allocator', type=int, choices=(0,1),
    help='explicit cached runtime allocator candidate; requires separate memory/quality gates')
args = parser.parse_args()
if args.decode_ctas is not None and args.prefill_ctas is None:
    raise ValueError('Decode CTA override requires an explicit prefill CTA count')
reference_path, directory = args.reference, args.directory
reference_bytes = reference_path.read_bytes()
reference = json.loads(reference_bytes)
if reference.get('profiled_diagnostic') or reference.get('profile_decode_steps') or reference.get('profile_prefill'):
    raise ValueError('Expected unprofiled completed reference')
if directory.exists():
    raise FileExistsError(directory)
shape_overrides = dict(batch=args.batch,output=args.output,
    context=args.context,prefill_chunk=args.prefill_chunk)
specification = (candidate_shape(reference,reference_bytes,**shape_overrides)
    if any(value is not None for value in shape_overrides.values()) else None)
env = os.environ.copy()
for key in list(env):
    if key == 'GARNET_TRT_SYNC_ALLOCATOR' or key.startswith(('GARNET_GPT_OSS_', 'GARNET_TP_', 'GARNET_BATCH_', 'GARNET_RESIDENT_')):
        del env[key]
for key, value in reference['optimization_environment'].items():
    if key == runtime_switch_policy:
        parse_switch_us(value)
        continue  # Scheduling is selected only by the later serving CLI, never saved provenance.
    if key in ('GARNET_RESIDENT_REUSE_OUTPUT', 'GARNET_RESIDENT_NATIVE_GREEDY_MERGE',
               'GARNET_RESIDENT_FINAL_PREFILL_SAMPLE_ONLY', 'GARNET_RESIDENT_PATTERN_UPDATES',
               'GARNET_RESIDENT_NATIVE_GREEDY_STATE'):
        if value not in ('0','1'):
            raise ValueError('Invalid recorded resident host flag')
        continue  # Host observation/sampling controls do not select engine-loading policy.
    if key in ('GARNET_RESIDENT_PROFILE', 'GARNET_RESIDENT_WARMUPS', 'GARNET_RESIDENT_SESSION'):
        # Prior admission file/warmup controls are result provenance, not
        # inputs to a new sequential engine profile on another binary.
        continue
    if ((not key.startswith(('GARNET_GPT_OSS_', 'GARNET_TP_', 'GARNET_BATCH_')) and key != 'GARNET_TRT_SYNC_ALLOCATOR') or
            key.endswith(('_TOKEN', '_KEY', '_SECRET', '_PASSWORD')) or not isinstance(value, str)):
        raise ValueError('Invalid recorded optimization environment')
    env[key] = value
fused_key='GARNET_GPT_OSS_FUSED_MOE_TP_REDUCE'
saved_fused=env.get(fused_key,'0')
if saved_fused not in ('0','1'):
    raise ValueError('Invalid recorded fused MoE peer-reduction flag')
if saved_fused=='1' and args.fused_moe_tp_reduce is None:
    raise ValueError('Fused MoE peer reduction must be explicitly selected for each profile')
env[fused_key]=str(args.fused_moe_tp_reduce) if args.fused_moe_tp_reduce is not None else '0'
if args.prepacked_candidate:
    env['GARNET_GPT_OSS_MARLIN_PREPACKED'] = '1'
if env.get('GARNET_GPT_OSS_MARLIN_PREPACKED') != '1':
    raise ValueError('Reference must be from a completed prepacked workload')
overrides = {key: str(value) for key, value in (
    ('GARNET_GPT_OSS_MARLIN_CTAS_PER_SM', args.decode_ctas),
    ('GARNET_GPT_OSS_MARLIN_LARGE_PREFILL_BLOCK', args.large_prefill_block),
    ('GARNET_GPT_OSS_MARLIN_PREFILL_CTAS_PER_SM', args.prefill_ctas),
    ('GARNET_GPT_OSS_MARLIN_PREFILL_UP_CTAS_PER_SM', args.prefill_up_ctas),
    ('GARNET_GPT_OSS_MARLIN_PREFILL_UP_STAGES', args.prefill_up_stages),
    ('GARNET_GPT_OSS_MARLIN_PREFILL_DOWN_K', args.prefill_down_k),
    ('GARNET_GPT_OSS_MARLIN_PREFILL_DOWN_CTAS_PER_SM', args.prefill_down_ctas),
    ('GARNET_GPT_OSS_DIRECT_MAX_BATCH', args.direct_max_batch),
    ('GARNET_GPT_OSS_DIRECT_BATCH_CTAS', args.direct_ctas),
    ('GARNET_GPT_OSS_BF16_DECODE_ALLREDUCE', args.bf16_decode_allreduce),
    ('GARNET_GPT_OSS_MARLIN_BOUNDED_PREFILL', args.bounded_prefill),
    ('GARNET_GPT_OSS_DECODE_ROUTER_TENSORCORE', args.decode_router_tensorcore),
    ('GARNET_GPT_OSS_TENSOR_ROUTER_EXPERT_WARPS', args.tensor_router_warps),
    ('GARNET_GPT_OSS_PREFILL_GQA_QUERY_TILE', args.prefill_gqa_query_tile),
    ('GARNET_GPT_OSS_HYBRID_KV', args.hybrid_kv),
    ('GARNET_GPT_OSS_MARLIN_FAST_HOST_PACK', args.fast_host_pack),
    ('GARNET_GPT_OSS_BF16_PEER_GROUP', args.bf16_peer_group)) if value is not None}
if args.bf16_peer_group_ctas is not None:
    if env.get('GARNET_GPT_OSS_BF16_PEER_GROUP') != '1':
        raise ValueError('Peer-group CTA override requires the recorded owned peer group')
    overrides['GARNET_GPT_OSS_BF16_PEER_GROUP_CTAS'] = str(args.bf16_peer_group_ctas)
if args.bf16_peer_group_threads is not None:
    if env.get('GARNET_GPT_OSS_BF16_PEER_GROUP') != '1':
        raise ValueError('Peer-group thread override requires the recorded owned peer group')
    overrides['GARNET_GPT_OSS_BF16_PEER_GROUP_THREADS'] = str(args.bf16_peer_group_threads)
if args.bf16_peer_grid_signals is not None:
    if args.bf16_peer_grid_signals and overrides.get('GARNET_GPT_OSS_BF16_PEER_GROUP',
            env.get('GARNET_GPT_OSS_BF16_PEER_GROUP')) != '1':
        raise ValueError('Grid signaling requires the recorded owned peer group')
    overrides['GARNET_GPT_OSS_BF16_PEER_GRID_SIGNALS'] = str(args.bf16_peer_grid_signals)
if args.direct_max_batch is not None or args.direct_ctas is not None:
    if any(env.get(key) != '1' for key in ('GARNET_GPT_OSS_DIRECT_ALLREDUCE',
            'GARNET_GPT_OSS_DIRECT_BATCH_ALLREDUCE', 'GARNET_GPT_OSS_DIRECT_LARGE_BATCH_ALLREDUCE')):
        raise ValueError('Direct screen requires explicitly enabled recorded direct batch flags')
if args.prefill_down_ctas is not None:
    selected_k=overrides.get('GARNET_GPT_OSS_MARLIN_PREFILL_DOWN_K',
        env.get('GARNET_GPT_OSS_MARLIN_PREFILL_DOWN_K'))
    if selected_k not in (None,'64','128'):
        raise ValueError('Independent down CTA override requires the supported K64 or K128 path')
env.update(overrides)
if args.prefill_up_stages is not None and env.get('GARNET_GPT_OSS_MARLIN_LARGE_PREFILL_BLOCK') != '64':
    raise ValueError('Prefill up-stage override requires the large-prefill64 path')
grid_flag = env.get('GARNET_GPT_OSS_BF16_PEER_GRID_SIGNALS', '0')
if grid_flag not in ('0','1') or (grid_flag == '1' and env.get('GARNET_GPT_OSS_BF16_PEER_GROUP') != '1'):
    raise ValueError('Grid signaling must be0/1 and requires the owned peer group')
if env[fused_key]=='1' and env.get('GARNET_GPT_OSS_BF16_PEER_GROUP')!='1':
    raise ValueError('Fused MoE peer reduction requires the owned peer group')
if env.get('GARNET_GPT_OSS_TENSOR_ROUTER_EXPERT_WARPS','4') not in ('2','4'):
    raise ValueError('Invalid tensor-core router warp policy')
if env.get('GARNET_GPT_OSS_PREFILL_GQA_QUERY_TILE') not in (None,'2','4'):
    raise ValueError('Invalid shared-query GQA prefill tile')
if args.prefill_gqa_query_tile is not None and env.get('GARNET_GPT_OSS_PREFILL_TILED_64') != '1':
    raise ValueError('GQA query tile override requires recorded tiled head64 prefill')
if env.get('GARNET_GPT_OSS_BF16_PEER_GROUP_CTAS','64') not in ('64','128','188'):
    raise ValueError('Invalid owned peer-group CTA policy')
if env.get('GARNET_GPT_OSS_BF16_PEER_GROUP_THREADS','256') not in ('256','512'):
    raise ValueError('Invalid owned peer-group threads-per-CTA policy')
if env.get('GARNET_GPT_OSS_BF16_PEER_GROUP','0') != '1' and env.get('GARNET_GPT_OSS_BF16_PEER_GROUP_CTAS','64') != '64':
    raise ValueError('Peer-group CTA policy requires the owned peer group')
if env.get('GARNET_GPT_OSS_BF16_PEER_GROUP','0') != '1' and env.get('GARNET_GPT_OSS_BF16_PEER_GROUP_THREADS','256') != '256':
    raise ValueError('Peer-group thread policy requires the owned peer group')
env['GARNET_TRT_SYNC_ALLOCATOR'] = str(args.sync_allocator) if args.sync_allocator is not None else env.get('GARNET_TRT_SYNC_ALLOCATOR', '0')
if specification is not None:
    env['GARNET_BATCH_PREFILL_CHUNK'] = str(specification['prefill_chunk_tokens'])
build = Path(env.get('GARNET_BUILD_DIR', root / 'out/build/gpt-oss'))
tensorrt = Path(env.get('GARNET_TENSORRT_ROOT', root / 'ThirdPartySDK/TensorRT'))
env['GARNET_TRT_LOG_ENGINE_MEMORY'] = '1'
env['GARNET_RESIDENT_PADDED_PREFILL'] = str(int(args.padded_prefill))
env['XLANG3_PYTHON_LIB'] = str(root / 'ThirdPartySDK/Python-3.14.0/Lib')
env['PYTHONPATH'] = str(build / 'bin') + os.pathsep + env.get('PYTHONPATH', '')
env['LD_LIBRARY_PATH'] = os.pathsep.join([str(build / 'bin'), str(tensorrt / 'lib'),
                                        '/usr/local/nvidia/lib64', env.get('LD_LIBRARY_PATH', '')])
directory.mkdir(parents=True)
specification_path = directory / 'candidate-shape.json'
if specification is not None:
    specification_path.write_text(json.dumps(specification,indent=2))
report = directory / 'engine-loads.json'
log = directory / 'engine-loads.log'
lock = root / 'work/gpu-benchmark.lock'
# Keep this budget inspection exclusive despite not issuing model inference.
command = ['flock', '-n', str(lock), 'bash', '-c',
           '[[ -z $(nvidia-smi --query-compute-apps=pid --format=csv,noheader) ]] || exit 1; exec "$@"',
           'engine-profile', str(build / 'bin/xlang3'), str(Path(__file__).resolve()),
           '--runtime', str(reference_path.resolve()), str(report.resolve())]
if specification is not None:
    command.append(str(specification_path.resolve()))
if subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip():
    raise RuntimeError('Another GPU process is active')
with log.open('x') as handle:
    subprocess.run(command, env=env, stdout=handle, stderr=subprocess.STDOUT, check=True)
statistics = {}
pattern = re.compile(r'\[TRTEngineMemory\] device=(\d+) total_weights_bytes=(\d+) '
                     r'context_device_memory_upper_bound_bytes=(\d+) engine=(.+)')
for match in pattern.finditer(log.read_text()):
    device, weights, context, path = match.groups()
    phase = 'prefill' if '/prefill/' in path else 'decode' if '/decode/' in path else None
    if phase is None:
        raise ValueError('Unknown engine phase')
    record = dict(device=int(device), phase=phase, total_weights_bytes=int(weights),
        context_device_memory_upper_bound_bytes=int(context), engine_path=path,
        engine_sha256=file_sha256(path))
    key = (int(device), phase)
    if key in statistics and statistics[key] != record:
        raise ValueError('Inconsistent repeated engine statistics')
    statistics[key] = record
if len(statistics) != 4:
    raise ValueError('Expected exactly four engine statistics')
statistics = list(statistics.values())
result = json.loads(report.read_text())
result['engine_statistics'] = statistics
result['source_commit'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
result['reference_result'] = str(reference_path.resolve())
result['explicit_prepacked_candidate_override'] = args.prepacked_candidate
result['explicit_kernel_candidate_overrides'] = overrides
result['explicit_workload_candidate_overrides'] = shape_overrides
result['reference_result_sha256'] = file_sha256(reference_path)
report.write_text(json.dumps(result, indent=2))
print(json.dumps(statistics, indent=2))
print('Sequential engine statistics recorded; paired resident admission remains unproven')
