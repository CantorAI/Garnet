# SPDX-License-Identifier: Apache-2.0
"""Qwen3.5 still-image tower, fixed grid with one image per batch row."""
from .tensor_compat import tensor
T=tensor()
@T.fusion(name='qwen35_vision_encoder',role='vision_encoder',boundary='required')
def Qwen35VisionEncoder(patches,config,grid_h,grid_w):
    return patches * T.unary_op('qwen35_vision_encoder',grid_h=grid_h,grid_w=grid_w,
        hidden_size=config['hidden_size'],num_heads=config['num_heads'],depth=config['depth'],
        patch_size=config['patch_size'],temporal_patch_size=config['temporal_patch_size'],in_channels=config['in_channels'],
        spatial_merge_size=config['spatial_merge_size'],num_position_embeddings=config['num_position_embeddings'],
        out_hidden_size=config['out_hidden_size'],rope_theta=config.get('rope_parameters',{}).get('rope_theta',10000))
