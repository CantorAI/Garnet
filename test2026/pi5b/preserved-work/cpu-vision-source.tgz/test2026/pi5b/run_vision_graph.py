import sys,json,math
sys.path.insert(0,sys.argv[2]);sys.path.insert(0,sys.argv[3])
import tensor,garnet
from xModel.qwen35.vl_0_8b.vision_encoder import Qwen35VisionEncoder,T
with open(sys.argv[1]) as stream:f=json.load(stream)
symbol=tensor.input('image_patches',shape=f['shape'],dtype=tensor.float32)
@T.fusion(name='qwen35_vision_reference',boundary='required')
def forward(patches):return Qwen35VisionEncoder(patches,f['config'],f['grid_h'],f['grid_w'])
model=garnet.compiled_graph()
try:
    model.build(forward(symbol),[symbol],f['checkpoint']);times=[]
    for step in f['steps']:
        result=model.run([tensor.tensor(step['input'],shape=f['shape'],dtype=tensor.float32)])
        actual=result.tolist();assert len(actual)==len(step['expected'])
        for observed,wanted in zip(actual,step['expected']):
            assert math.isfinite(observed) and abs(observed-wanted)<=5e-6+5e-5*abs(wanted)
        times.append(model.last_inference_ms)
    print('actual Garnet vision graph batch',f['shape'][0],'grid',f['grid_h'],f['grid_w'],'PASS compile_ms',model.compile_ms,'inference_ms',times,flush=True)
finally:model.close()
