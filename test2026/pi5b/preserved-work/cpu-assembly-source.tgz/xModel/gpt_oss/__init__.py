"""GPT-OSS model family."""
