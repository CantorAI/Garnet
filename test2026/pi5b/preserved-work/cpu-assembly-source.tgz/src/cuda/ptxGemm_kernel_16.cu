// SPDX-FileCopyrightText: 2024-2026 CantorAI Inc.
// SPDX-License-Identifier: Apache-2.0

// ptxGemm_kernel.cu
#include <cuda_runtime.h>
#include <cuda_fp16.h>    // For __half and __float2half
#include <cuda_bf16.h>    // For __nv_bfloat16
#include <cuda_fp8.h>     // For __nv_fp8_e4m3 and __nv_fp8_e5m2

// Set to 0 to disable FP8 kernels
#define _FP8_SUPPORT_ 1

extern "C" {

    //------------------------------------------------------------------------------
    // FP16 Kernel
     //------------------------------------------------------------------------------
    // �������FP16�ں�
    __global__ void gemm_kernel_fp16(const __half* A, const __half* B, __half* C,
        int M, int K, int N) {
        // ��ά�߳̿�: ÿ���߳̿鴦��һ��16x16�����
        int row_in_block = threadIdx.y; // �߳��ڿ��ڵ���ID (0-15)
        int col_in_block = threadIdx.x; // �߳��ڿ��ڵ���ID (0-15)

        int block_row = blockIdx.y;     // ������������
        int block_col = blockIdx.x;     // ������������

        // �����������C�е�ȫ������
        int row = block_row * 16 + row_in_block;
        int col = block_col * 16 + col_in_block;

        // �����ڴ����� (ÿ����16x16)
        __shared__ __half tileA[16][16];
        __shared__ __half tileB[16][16];

        float accum = 0.0f;

        // ��Kά�ȷֿ鴦��
        for (int t = 0; t < K; t += 16) {
            // Э������A��tile (������)
            int load_row = row_in_block;
            int load_col = t + col_in_block;
            if (row < M && load_col < K) {
                tileA[row_in_block][col_in_block] = A[row * K + load_col];
            }
            else {
                tileA[row_in_block][col_in_block] = __float2half(0.0f);
            }

            // Э������B��tile (������)
            load_row = t + row_in_block;
            load_col = col;
            if (load_row < K && col < N) {
                tileB[row_in_block][col_in_block] = B[load_row * N + col];
            }
            else {
                tileB[row_in_block][col_in_block] = __float2half(0.0f);
            }
            __syncthreads();

            // ���㵱ǰtile��accum�Ĺ���
            for (int k = 0; k < 16; k++) {
                accum += __half2float(tileA[row_in_block][k]) *
                    __half2float(tileB[k][col_in_block]);
            }
            __syncthreads();
        }

        // �����д��ȫ���ڴ�
        if (row < M && col < N) {
            C[row * N + col] = __float2half(accum);
        }
    }

    //------------------------------------------------------------------------------
    // �������BF16�ں�
    __global__ void gemm_kernel_bf16(const __nv_bfloat16* A, const __nv_bfloat16* B, __nv_bfloat16* C,
        int M, int K, int N) {
        // ��ά�߳̿�: ÿ���߳̿鴦��һ��16x16�����
        int row_in_block = threadIdx.y;
        int col_in_block = threadIdx.x;

        int block_row = blockIdx.y;
        int block_col = blockIdx.x;

        int row = block_row * 16 + row_in_block;
        int col = block_col * 16 + col_in_block;

        __shared__ __nv_bfloat16 tileA[16][16];
        __shared__ __nv_bfloat16 tileB[16][16];

        float accum = 0.0f;
        for (int t = 0; t < K; t += 16) {
            // Э������A��tile
            int load_row = row_in_block;
            int load_col = t + col_in_block;
            if (row < M && load_col < K) {
                tileA[row_in_block][col_in_block] = A[row * K + load_col];
            }
            else {
                tileA[row_in_block][col_in_block] = __float2bfloat16(0.0f);
            }

            // Э������B��tile
            load_row = t + row_in_block;
            load_col = col;
            if (load_row < K && col < N) {
                tileB[row_in_block][col_in_block] = B[load_row * N + col];
            }
            else {
                tileB[row_in_block][col_in_block] = __float2bfloat16(0.0f);
            }
            __syncthreads();

            // �����ۼ�ֵ
            for (int k = 0; k < 16; k++) {
                accum += __bfloat162float(tileA[row_in_block][k]) *
                    __bfloat162float(tileB[k][col_in_block]);
            }
            __syncthreads();
        }

        // д����
        if (row < M && col < N) {
            C[row * N + col] = __float2bfloat16(accum);
        }
    }

    __global__ void gemm_kernel_fp32(const float* A, const float* B, float* C,
        int M, int N, int K) {
        // ��ά�߳̿�: ÿ���߳̿鴦��һ��16x16�����
        int row_in_block = threadIdx.y; // �߳��ڿ��ڵ���ID (0-15)
        int col_in_block = threadIdx.x; // �߳��ڿ��ڵ���ID (0-15)

        int block_row = blockIdx.y;     // ������������
        int block_col = blockIdx.x;     // ������������

        // �����������C�е�ȫ������
        int row = block_row * 16 + row_in_block;
        int col = block_col * 16 + col_in_block;

        // �����ڴ����� (ÿ����16x16)
        __shared__ float tileA[16][16];
        __shared__ float tileB[16][16];

        float accum = 0.0f;

        // ��Kά�ȷֿ鴦��
        for (int t = 0; t < K; t += 16) {
            // Э������A��tile (������)
            int load_row = row_in_block;
            int load_col = t + col_in_block;
            if (row < M && load_col < K) {
                tileA[row_in_block][col_in_block] = A[row * K + load_col];
            }
            else {
                tileA[row_in_block][col_in_block] = 0.0f;
            }

            // Э������B��tile (������)
            load_row = t + row_in_block;
            load_col = col;
            if (load_row < K && col < N) {
                tileB[row_in_block][col_in_block] = B[load_row * N + col];
            }
            else {
                tileB[row_in_block][col_in_block] = 0.0f;
            }
            __syncthreads();

            // ���㵱ǰtile��accum�Ĺ���
                for (int k = 0; k < 16; k++) {
                accum += tileA[row_in_block][k] * tileB[k][col_in_block];
            }
            __syncthreads();
        }

        // �����д��ȫ���ڴ�
        if (row < M && col < N) {
            C[row * N + col] = accum;
        }
    }

    //------------------------------------------------------------------------------
    // Wrapper functions: each launches the corresponding kernel over a grid covering the full matrix.
    // Assumes that M, N, and K are multiples of 16.
    void runGemmFP16(__half* d_A, __half* d_B, __half* d_C,
        int m, int k, int n) {
        // ��ά�߳̿�: 16x16 = 256 threads/block
        dim3 blockDim(16, 16);

        // ���񲼾�: ÿ���鴦��16x16���
        dim3 gridDim((n + 15) / 16, (m + 15) / 16);

        gemm_kernel_fp16 << <gridDim, blockDim >> > (d_A, d_B, d_C, m, k, n);
        cudaDeviceSynchronize();
    }

    void runGemmBF16(__nv_bfloat16* d_A, __nv_bfloat16* d_B, __nv_bfloat16* d_C,
        int m, int k, int n) {
        // ��ά�߳̿�: 16x16 = 256 threads/block
        dim3 blockDim(16, 16);

        // ���񲼾�: ÿ���鴦��16x16���
        dim3 gridDim((n + 15) / 16, (m + 15) / 16);

        gemm_kernel_bf16 << <gridDim, blockDim >> > (d_A, d_B, d_C, m, k, n);
        cudaDeviceSynchronize();
    }

#if _FP8_SUPPORT_
    // �������FP8 E4M3�ں�
    __global__ void gemm_kernel_fp8_e4m3(const __nv_fp8_e4m3* A, const __nv_fp8_e4m3* B, __nv_fp8_e4m3* C,
        int M, int N, int K) {
        int row = blockIdx.y * blockDim.y + threadIdx.y;
        int col = blockIdx.x * blockDim.x + threadIdx.x;

        if (row >= M || col >= N) return;

        float accum = 0.0f;
        for (int k = 0; k < K; ++k) {
            float a_val = static_cast<float>(A[row * K + k]);
            float b_val = static_cast<float>(B[k * N + col]);
            accum += a_val * b_val;
        }

        // �����ת��ΪFP8�洢
        C[row * N + col] = __nv_fp8_e4m3(accum);
    }

    // �������FP8 E5M2�ں�
    __global__ void gemm_kernel_fp8_e5m2(const __nv_fp8_e5m2* A, const __nv_fp8_e5m2* B, __nv_fp8_e5m2* C,
        int M, int N, int K) {
        int row = blockIdx.y * blockDim.y + threadIdx.y;
        int col = blockIdx.x * blockDim.x + threadIdx.x;

        if (row >= M || col >= N) return;

        float accum = 0.0f;
        for (int k = 0; k < K; ++k) {
            float a_val = static_cast<float>(A[row * K + k]);
            float b_val = static_cast<float>(B[k * N + col]);
            accum += a_val * b_val;
        }

        // �����ת��ΪFP8�洢
        C[row * N + col] = __nv_fp8_e5m2(accum);
    }
#endif

#if _FP8_SUPPORT_
    // ����������к���
    void runGemmFP8E4M3(const __nv_fp8_e4m3* d_A, const __nv_fp8_e4m3* d_B, __nv_fp8_e4m3* d_C,
        int m, int n, int k) {  // ����˳��ͳһΪm,n,k

        // ���������߳̿�����
        dim3 blockDim(16, 16);
        dim3 gridDim((n + blockDim.x - 1) / blockDim.x,
            (m + blockDim.y - 1) / blockDim.y);

        gemm_kernel_fp8_e4m3 << <gridDim, blockDim >> > (d_A, d_B, d_C, m, n, k);
        cudaDeviceSynchronize();
    }

    void runGemmFP8E5M2(const __nv_fp8_e5m2* d_A, const __nv_fp8_e5m2* d_B, __nv_fp8_e5m2* d_C,
        int m, int n, int k) {  // ����˳��ͳһΪm,n,k

        // ���������߳̿�����
        dim3 blockDim(16, 16);
        dim3 gridDim((n + blockDim.x - 1) / blockDim.x,
            (m + blockDim.y - 1) / blockDim.y);

        gemm_kernel_fp8_e5m2 << <gridDim, blockDim >> > (d_A, d_B, d_C, m, n, k);
        cudaDeviceSynchronize();
    }
#endif

    //void runGemmFP32(const float* d_A, const float* d_B, float* d_C,
    //    int M, int N, int K) {
    //    dim3 gridDim(N / 16, M / 16);
    //    dim3 blockDim(32, 1, 1);
    //    gemm_kernel_fp32 << <gridDim, blockDim >> > (d_A, d_B, d_C, M, N, K);
    //    cudaDeviceSynchronize();
    //}

    void runGemmFP32(const float* d_A, const float* d_B, float* d_C,
        int M, int N, int K) {
        // ��ά�߳̿�: 16x16 = 256 threads/block
        dim3 blockDim(16, 16); // �����߳̿鲼��

        // ���񲼾�: ÿ���鴦��16x16���
        dim3 gridDim((N + 15) / 16, (M + 15) / 16); // ������16�����ߴ�

        gemm_kernel_fp32 << <gridDim, blockDim >> > (d_A, d_B, d_C, M, N, K);
        cudaDeviceSynchronize();
    }

} // extern "C"