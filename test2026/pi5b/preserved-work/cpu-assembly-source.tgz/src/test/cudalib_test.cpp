// SPDX-FileCopyrightText: 2024-2026 CantorAI Inc.
// SPDX-License-Identifier: Apache-2.0

#include <iostream>
#include <vector>
#include <cassert>
#include <random>
#include <cmath>
#include <thrust/device_vector.h>
#include <thrust/host_vector.h>
#include <climits>
#include <cstdint>
#include <system_error>
#include "cuda_lib.h"

#ifdef _WIN32
#include <windows.h>
#undef min
#undef max
#endif

// Test precision
#define EPSILON float(1e-3)//float(1e-4)
#define FP16_EPSILON float(1e-2)
#define BF16_EPSILON float(1e-1)
#define FP8_EPSILON float(2e-1)

// Random number generation
std::mt19937 rng(std::random_device{}());
std::uniform_real_distribution<float> float_dist(-10.0f, 10.0f);
std::uniform_int_distribution<int> int_dist(0, 100);
std::uniform_real_distribution<double> double_dist(-10.0, 10.0);

// Test status
enum TestStatus {
    PASS,
    FAIL,
    SKIP
};

// Test report
struct TestReport {
    std::string functionName;
    TestStatus status;
    std::string message;

    TestReport(const std::string& name, TestStatus stat, const std::string& msg = "")
        : functionName(name), status(stat), message(msg) {
    }
};

// Print test report
void printTestReport(const TestReport& report) {
    std::string statusStr = (report.status == PASS) ? "PASS" :
        (report.status == FAIL) ? "FAIL" : "SKIP";
    std::cout << "[" << statusStr << "] " << report.functionName;
    if (report.status == FAIL && !report.message.empty()) {
        std::cout << ": " << report.message;
    }
    std::cout << std::endl;
}

// Helper function to compare floating point values with epsilon
template<typename T>
bool almostEqual(T a, T b, T epsilon) {
    return std::abs(a - b) <= epsilon;
}

// ------------------------
// Memory Management Tests
// ------------------------

TestReport testZeroInitializeFP32() {
    try {
        const int count = 1000;
        float* d_data;
        cudaMalloc(&d_data, count * sizeof(float));
        runZeroInitializeFP32(d_data, count);

        std::vector<float> h_data(count);
        cudaMemcpy(h_data.data(), d_data, count * sizeof(float), cudaMemcpyDeviceToHost);

        for (int i = 0; i < count; i++) {
            if (h_data[i] != 0.0f) {
                cudaFree(d_data);
                return TestReport("runZeroInitializeFP32", FAIL, "Non-zero value found");
            }
        }

        cudaFree(d_data);
        return TestReport("runZeroInitializeFP32", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runZeroInitializeFP32", FAIL, e.what());
    }
}

TestReport testZeroInitializeFP16() {
    try {
        const int count = 1000;
        __half* d_data;
        cudaMalloc(&d_data, count * sizeof(__half));
        runZeroInitializeFP16(d_data, count);

        std::vector<__half> h_data(count);
        cudaMemcpy(h_data.data(), d_data, count * sizeof(__half), cudaMemcpyDeviceToHost);

        for (int i = 0; i < count; i++) {
            if (__half2float(h_data[i]) != 0.0f) {
                cudaFree(d_data);
                return TestReport("runZeroInitializeFP16", FAIL, "Non-zero value found");
            }
        }

        cudaFree(d_data);
        return TestReport("runZeroInitializeFP16", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runZeroInitializeFP16", FAIL, e.what());
    }
}

TestReport testZeroInitializeBF16() {
    try {
        const int count = 1000;
        bfloat16* d_data;
        cudaMalloc(&d_data, count * sizeof(bfloat16));
        runZeroInitializeBF16(d_data, count);

        std::vector<bfloat16> h_data(count);
        cudaMemcpy(h_data.data(), d_data, count * sizeof(bfloat16), cudaMemcpyDeviceToHost);

        for (int i = 0; i < count; i++) {
            if (__bfloat162float(h_data[i]) != 0.0f) {
                cudaFree(d_data);
                return TestReport("runZeroInitializeBF16", FAIL, "Non-zero value found");
            }
        }

        cudaFree(d_data);
        return TestReport("runZeroInitializeBF16", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runZeroInitializeBF16", FAIL, e.what());
    }
}

// ------------------------
// Multiply Kernels Tests
// ------------------------

TestReport testGemmFP32() {
    try {
        const int m = 32, k = 64, n = 16;
        const int sizeA = m * k;
        const int sizeB = k * n;
        const int sizeC = m * n;

        std::vector<float> h_A(sizeA);
        std::vector<float> h_B(sizeB);
        std::vector<float> h_C(sizeC, 0);
        std::vector<float> h_C_expected(sizeC, 0);

        // Generate test data
        for (int i = 0; i < sizeA; i++) h_A[i] = float_dist(rng);
        for (int i = 0; i < sizeB; i++) h_B[i] = float_dist(rng);

        // Compute expected result (CPU version)
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                float sum = 0;
                for (int p = 0; p < k; p++) {
                    sum += h_A[i * k + p] * h_B[p * n + j];
                }
                h_C_expected[i * n + j] = sum;
            }
        }

        // Allocate GPU memory
        float* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, sizeA * sizeof(float));
        cudaMalloc(&d_B, sizeB * sizeof(float));
        cudaMalloc(&d_C, sizeC * sizeof(float));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), sizeA * sizeof(float), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), sizeB * sizeof(float), cudaMemcpyHostToDevice);
        cudaMemset(d_C, 0, sizeC * sizeof(float));

        // Execute GPU computation
        runGemmFP32(d_A, d_B, d_C, m, n, k);

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, sizeC * sizeof(float), cudaMemcpyDeviceToHost);

        // Verify results
        for (int i = 0; i < sizeC; i++) {
            if (!almostEqual(h_C[i], h_C_expected[i], static_cast<float>(EPSILON))) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runGemmFP32", FAIL, "Result mismatch at index " + std::to_string(i));
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runGemmFP32", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runGemmFP32", FAIL, e.what());
    }
}

TestReport testGemmFP16() {
    try {
        const int m = 32, k = 64, n = 16;
        const int sizeA = m * k;
        const int sizeB = k * n;
        const int sizeC = m * n;

        std::vector<__half> h_A(sizeA);
        std::vector<__half> h_B(sizeB);
        std::vector<__half> h_C(sizeC);
        std::vector<float> h_C_expected(sizeC, 0);

        // Generate test data
        for (int i = 0; i < sizeA; i++) h_A[i] = __float2half(float_dist(rng));
        for (int i = 0; i < sizeB; i++) h_B[i] = __float2half(float_dist(rng));

        // Compute expected result (CPU version) - ������B�������������
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                float sum = 0;
                for (int p = 0; p < k; p++) {
                    // ����: B[p * n + j] -> B[p * n + j] ����ȷ����
                    // ����Ҫȷ��B�����������ȴ洢 (k x n)
                    sum += __half2float(h_A[i * k + p]) * __half2float(h_B[p * n + j]);
                }
                h_C_expected[i * n + j] = sum;
            }
        }

        // Allocate GPU memory
        __half* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, sizeA * sizeof(__half));
        cudaMalloc(&d_B, sizeB * sizeof(__half));
        cudaMalloc(&d_C, sizeC * sizeof(__half));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), sizeA * sizeof(__half), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), sizeB * sizeof(__half), cudaMemcpyHostToDevice);
        cudaMemset(d_C, 0, sizeC * sizeof(__half));

        // ����: ����˳���Ϊ (m, k, n)
        runGemmFP16(d_A, d_B, d_C, m, k, n);  // ��ȷ˳��: m, k, n

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, sizeC * sizeof(__half), cudaMemcpyDeviceToHost);

        // Verify results
        for (int i = 0; i < sizeC; i++) {
            float actual = __half2float(h_C[i]);
            // ʹ��������Ƚϸ�����
            float expected = h_C_expected[i];
            float abs_error = fabs(actual - expected);
            float rel_error = abs_error / fmax(1.0f, fabs(expected));

            if (rel_error > FP16_EPSILON) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runGemmFP16", FAIL,
                    "Result mismatch at index " + std::to_string(i) +
                    " Expected: " + std::to_string(expected) +
                    " Actual: " + std::to_string(actual) +
                    " Rel error: " + std::to_string(rel_error));
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runGemmFP16", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runGemmFP16", FAIL, e.what());
    }
}

TestReport testGemmBF16() {
    try {
        const int m = 32, k = 64, n = 16;
        const int sizeA = m * k;
        const int sizeB = k * n;
        const int sizeC = m * n;

        // ����: ʹ����ȷ���������� __nv_bfloat16
        std::vector<__nv_bfloat16> h_A(sizeA);
        std::vector<__nv_bfloat16> h_B(sizeB);
        std::vector<__nv_bfloat16> h_C(sizeC);
        std::vector<float> h_C_expected(sizeC, 0);

        // Generate test data
        for (int i = 0; i < sizeA; i++) h_A[i] = __float2bfloat16(float_dist(rng));
        for (int i = 0; i < sizeB; i++) h_B[i] = __float2bfloat16(float_dist(rng));

        // Compute expected result (CPU version) - ������B�������������
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                float sum = 0;
                for (int p = 0; p < k; p++) {
                    // ����: B[p * n + j] -> B[p * n + j] ����ȷ����
                    sum += __bfloat162float(h_A[i * k + p]) * __bfloat162float(h_B[p * n + j]);
                }
                h_C_expected[i * n + j] = sum;
            }
        }

        // Allocate GPU memory - ����: ʹ����ȷ���������� __nv_bfloat16
        __nv_bfloat16* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, sizeA * sizeof(__nv_bfloat16));
        cudaMalloc(&d_B, sizeB * sizeof(__nv_bfloat16));
        cudaMalloc(&d_C, sizeC * sizeof(__nv_bfloat16));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), sizeA * sizeof(__nv_bfloat16), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), sizeB * sizeof(__nv_bfloat16), cudaMemcpyHostToDevice);
        cudaMemset(d_C, 0, sizeC * sizeof(__nv_bfloat16));

        // ����: ����˳���Ϊ (m, k, n)
        runGemmBF16(d_A, d_B, d_C, m, k, n);  // ��ȷ˳��: m, k, n

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, sizeC * sizeof(__nv_bfloat16), cudaMemcpyDeviceToHost);

        // Verify results
        for (int i = 0; i < sizeC; i++) {
            float actual = __bfloat162float(h_C[i]);
            // ʹ��������Ƚϸ�����
            float expected = h_C_expected[i];
            float abs_error = fabs(actual - expected);
            float rel_error = abs_error / fmax(1.0f, fabs(expected));

            if (rel_error > BF16_EPSILON) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runGemmBF16", FAIL,
                    "Result mismatch at index " + std::to_string(i) +
                    " Expected: " + std::to_string(expected) +
                    " Actual: " + std::to_string(actual) +
                    " Rel error: " + std::to_string(rel_error));
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runGemmBF16", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runGemmBF16", FAIL, e.what());
    }
}

// Helper function to convert float to fp8_e4m3
fp8_e4m3 float_to_fp8_e4m3(float f) {
    fp8_e4m3 result;
    // Simple conversion (actual implementation may vary)
    result = fp8_e4m3(fminf(fmaxf(f * 8.0f, -8.0f), 8.0f) * 16.0f);
    return result;
}

// Helper function to convert fp8_e4m3 to float
float fp8_e4m3_to_float(fp8_e4m3 f) {
    // Simple conversion (actual implementation may vary)
    return static_cast<float>(f) / 16.0f;
}

// Helper function to convert float to fp8_e5m2
fp8_e5m2 float_to_fp8_e5m2(float f) {
    fp8_e5m2 result;
    // Simple conversion (actual implementation may vary)
    result = fp8_e5m2(fminf(fmaxf(f * 4.0f, -16.0f), 16.0f) * 8.0f);
    return result;
}

// Helper function to convert fp8_e5m2 to float
float fp8_e5m2_to_float(fp8_e5m2 f) {
    // Simple conversion (actual implementation may vary)
    return static_cast<float>(f) / 8.0f;
}

TestReport testGemmFP8E4M3() {
    try {
        const int m = 16, k = 32, n = 8;  // Smaller sizes for FP8 testing
        const int sizeA = m * k;
        const int sizeB = k * n;
        const int sizeC = m * n;

        std::vector<fp8_e4m3> h_A(sizeA);
        std::vector<fp8_e4m3> h_B(sizeB);
        std::vector<fp8_e4m3> h_C(sizeC);
        std::vector<float> h_C_expected(sizeC, 0);

        // Generate test data in range that FP8 can handle
        std::uniform_real_distribution<float> fp8_dist(-2.0f, 2.0f);

        for (int i = 0; i < sizeA; i++) {
            h_A[i] = float_to_fp8_e4m3(fp8_dist(rng));
        }
        for (int i = 0; i < sizeB; i++) {
            h_B[i] = float_to_fp8_e4m3(fp8_dist(rng));
        }

        // Compute expected result (CPU version)
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                float sum = 0;
                for (int p = 0; p < k; p++) {
                    sum += fp8_e4m3_to_float(h_A[i * k + p]) *
                        fp8_e4m3_to_float(h_B[p * n + j]);
                }
                h_C_expected[i * n + j] = sum;
            }
        }

        // Allocate GPU memory
        fp8_e4m3* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, sizeA * sizeof(fp8_e4m3));
        cudaMalloc(&d_B, sizeB * sizeof(fp8_e4m3));
        cudaMalloc(&d_C, sizeC * sizeof(fp8_e4m3));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), sizeA * sizeof(fp8_e4m3), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), sizeB * sizeof(fp8_e4m3), cudaMemcpyHostToDevice);
        cudaMemset(d_C, 0, sizeC * sizeof(fp8_e4m3));

        // Execute GPU computation
        runGemmFP8E4M3(d_A, d_B, d_C, m, k, n);

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, sizeC * sizeof(fp8_e4m3), cudaMemcpyDeviceToHost);

        // Verify results with higher tolerance for FP8
        const float fp8_epsilon = 0.1f;  // Larger epsilon for FP8 precision
        for (int i = 0; i < sizeC; i++) {
            float actual = fp8_e4m3_to_float(h_C[i]);
            float expected = h_C_expected[i];

            if (fabs(expected) < 1e-6) {
                // Near-zero values - check absolute difference
                if (fabs(actual - expected) > fp8_epsilon) {
                    cudaFree(d_A);
                    cudaFree(d_B);
                    cudaFree(d_C);
                    return TestReport("runGemmFP8E4M3", FAIL,
                        "Result mismatch at index " + std::to_string(i) +
                        " Expected: " + std::to_string(expected) +
                        " Actual: " + std::to_string(actual));
                }
            }
            else {
                // Non-zero values - check relative difference
                if (fabs((actual - expected) / expected) > fp8_epsilon) {
                    cudaFree(d_A);
                    cudaFree(d_B);
                    cudaFree(d_C);
                    return TestReport("runGemmFP8E4M3", FAIL,
                        "Result mismatch at index " + std::to_string(i) +
                        " Expected: " + std::to_string(expected) +
                        " Actual: " + std::to_string(actual));
                }
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runGemmFP8E4M3", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runGemmFP8E4M3", FAIL, e.what());
    }
}

TestReport testGemmFP8E5M2() {
    try {
        const int m = 16, k = 32, n = 8;  // Smaller sizes for FP8 testing
        const int sizeA = m * k;
        const int sizeB = k * n;
        const int sizeC = m * n;

        std::vector<fp8_e5m2> h_A(sizeA);
        std::vector<fp8_e5m2> h_B(sizeB);
        std::vector<fp8_e5m2> h_C(sizeC);
        std::vector<float> h_C_expected(sizeC, 0);

        // Generate test data in range that FP8 can handle
        std::uniform_real_distribution<float> fp8_dist(-4.0f, 4.0f);

        for (int i = 0; i < sizeA; i++) {
            h_A[i] = float_to_fp8_e5m2(fp8_dist(rng));
        }
        for (int i = 0; i < sizeB; i++) {
            h_B[i] = float_to_fp8_e5m2(fp8_dist(rng));
        }

        // Compute expected result (CPU version)
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                float sum = 0;
                for (int p = 0; p < k; p++) {
                    sum += fp8_e5m2_to_float(h_A[i * k + p]) *
                        fp8_e5m2_to_float(h_B[p * n + j]);
                }
                h_C_expected[i * n + j] = sum;
            }
        }

        // Allocate GPU memory
        fp8_e5m2* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, sizeA * sizeof(fp8_e5m2));
        cudaMalloc(&d_B, sizeB * sizeof(fp8_e5m2));
        cudaMalloc(&d_C, sizeC * sizeof(fp8_e5m2));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), sizeA * sizeof(fp8_e5m2), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), sizeB * sizeof(fp8_e5m2), cudaMemcpyHostToDevice);
        cudaMemset(d_C, 0, sizeC * sizeof(fp8_e5m2));

        // Execute GPU computation
        runGemmFP8E5M2(d_A, d_B, d_C, m, k, n);

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, sizeC * sizeof(fp8_e5m2), cudaMemcpyDeviceToHost);

        // Verify results with higher tolerance for FP8
        const float fp8_epsilon = 0.15f;  // Larger epsilon for FP8 precision
        for (int i = 0; i < sizeC; i++) {
            float actual = fp8_e5m2_to_float(h_C[i]);
            float expected = h_C_expected[i];

            if (fabs(expected) < 1e-6) {
                // Near-zero values - check absolute difference
                if (fabs(actual - expected) > fp8_epsilon) {
                    cudaFree(d_A);
                    cudaFree(d_B);
                    cudaFree(d_C);
                    return TestReport("runGemmFP8E5M2", FAIL,
                        "Result mismatch at index " + std::to_string(i) +
                        " Expected: " + std::to_string(expected) +
                        " Actual: " + std::to_string(actual));
                }
            }
            else {
                // Non-zero values - check relative difference
                if (fabs((actual - expected) / expected) > fp8_epsilon) {
                    cudaFree(d_A);
                    cudaFree(d_B);
                    cudaFree(d_C);
                    return TestReport("runGemmFP8E5M2", FAIL,
                        "Result mismatch at index " + std::to_string(i) +
                        " Expected: " + std::to_string(expected) +
                        " Actual: " + std::to_string(actual));
                }
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runGemmFP8E5M2", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runGemmFP8E5M2", FAIL, e.what());
    }
}

TestReport testSingleElementTensorMultiplyFP32() {
    try {
        const int count = 1024;
        std::vector<float> h_A(count);
        std::vector<float> h_B(count);
        std::vector<float> h_C(count);
        std::vector<float> h_expected(count);

        // Generate test data
        h_B.assign(count, float(0.0f));
        float valB = float_dist(rng);
        h_B[0] = valB;
        for (int i = 0; i < count; i++) {
            h_A[i] = float_dist(rng);
            h_expected[i] = h_A[i] * valB;
        }

        // Allocate GPU memory
        float* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, count * sizeof(float));
        cudaMalloc(&d_B, count * sizeof(float));
        cudaMalloc(&d_C, count * sizeof(float));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), count * sizeof(float), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), count * sizeof(float), cudaMemcpyHostToDevice);

        // Execute GPU computation
        runSingleElementTensorMultiplyFP32(d_A, d_B, d_C, count);

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, count * sizeof(float), cudaMemcpyDeviceToHost);

        // Verify results
        for (int i = 0; i < count; i++) {
            if (!almostEqual(h_C[i], h_expected[i], static_cast<float>(EPSILON))) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runSingleElementTensorMultiplyFP32", FAIL,
                    "Result mismatch at index " + std::to_string(i));
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runSingleElementTensorMultiplyFP32", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runSingleElementTensorMultiplyFP32", FAIL, e.what());
    }
}


TestReport testSingleElementTensorMultiplyFP16() {  // �޸ĺ�������ƥ��ʵ��
    try {
        const int count = 1024;
        std::vector<__half> h_A(count);
        std::vector<__half> h_B(count);
        std::vector<__half> h_C(count);
        std::vector<float> h_expected(count);

        // ��ʼ�������������
        std::random_device rd;
        std::mt19937 rng(rd());
        std::uniform_real_distribution<float> float_dist(0.1f, 1.0f);  // ���ӷֲ�����

        // Generate test data
        h_B.assign(count, __half(0.0f));
        float valB = float_dist(rng);
        h_B[0] = __float2half(valB);
        for (int i = 0; i < count; i++) {
            h_A[i] = __float2half(float_dist(rng));
            h_expected[i] = __half2float(h_A[i]) * valB;
        }

        // Allocate GPU memory
        __half* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, count * sizeof(__half));
        cudaMalloc(&d_B, count * sizeof(__half));
        cudaMalloc(&d_C, count * sizeof(__half));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), count * sizeof(__half), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), count * sizeof(__half), cudaMemcpyHostToDevice);

        // Execute GPU computation - ʹ��������ĺ�����
        runSingleElementTensorMultiplyFP16(d_A, d_B, d_C, count);

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, count * sizeof(__half), cudaMemcpyDeviceToHost);

        // ���Ӹ������ȽϺ��� (���δ����)
        auto almostEqual = [](float a, float b, float epsilon) {
            return std::fabs(a - b) < epsilon;
            };

        // Verify results
        for (int i = 0; i < count; i++) {
            float actual = __half2float(h_C[i]);
            if (!almostEqual(actual, h_expected[i], FP16_EPSILON)) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runSingleElementTensorMultiplyFP16", FAIL,  // ���²�����
                    "Result mismatch at index " + std::to_string(i) +
                    " Expected: " + std::to_string(h_expected[i]) +
                    " Actual: " + std::to_string(actual));
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runSingleElementTensorMultiplyFP16", PASS);  // ���²�����
    }
    catch (const std::exception& e) {
        return TestReport("runSingleElementTensorMultiplyFP16", FAIL, e.what());  // ���²�����
    }
}

TestReport testScalarMultiplyFP32() {
    try {
        const int count = 1024;
        const float scalar = float_dist(rng);
        std::vector<float> h_input(count);
        std::vector<float> h_result(count);
        std::vector<float> h_expected(count);

        // Generate test data
        for (int i = 0; i < count; i++) {
            h_input[i] = float_dist(rng);
            h_expected[i] = h_input[i] * scalar;
        }

        // Allocate GPU memory
        float* d_input, * d_result;
        cudaMalloc(&d_input, count * sizeof(float));
        cudaMalloc(&d_result, count * sizeof(float));

        // Copy data to GPU
        cudaMemcpy(d_input, h_input.data(), count * sizeof(float), cudaMemcpyHostToDevice);

        // Execute GPU computation
        runScalarMultiplyFP32(d_input, d_result, scalar, count);

        // Copy result back to CPU
        cudaMemcpy(h_result.data(), d_result, count * sizeof(float), cudaMemcpyDeviceToHost);

        // Verify results
        for (int i = 0; i < count; i++) {
            if (!almostEqual(h_result[i], h_expected[i], static_cast<float>(EPSILON))) {
                cudaFree(d_input);
                cudaFree(d_result);
                return TestReport("runScalarMultiplyFP32", FAIL,
                    "Result mismatch at index " + std::to_string(i));
            }
        }

        cudaFree(d_input);
        cudaFree(d_result);
        return TestReport("runScalarMultiplyFP32", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runScalarMultiplyFP32", FAIL, e.what());
    }
}

TestReport testScalarMultiplyFP16() {
    try {
        const int count = 1024;
        const float scalar = float_dist(rng);
        std::vector<__half> h_input(count);
        std::vector<__half> h_result(count);
        std::vector<float> h_expected(count);

        // Generate test data
        for (int i = 0; i < count; i++) {
            h_input[i] = __float2half(float_dist(rng));
            h_expected[i] = __half2float(h_input[i]) * scalar;
        }

        // Allocate GPU memory
        __half* d_input, * d_result;
        cudaMalloc(&d_input, count * sizeof(__half));
        cudaMalloc(&d_result, count * sizeof(__half));

        // Copy data to GPU
        cudaMemcpy(d_input, h_input.data(), count * sizeof(__half), cudaMemcpyHostToDevice);

        // Execute GPU computation
        runScalarMultiplyFP16(d_input, d_result, scalar, count);

        // Copy result back to CPU
        cudaMemcpy(h_result.data(), d_result, count * sizeof(__half), cudaMemcpyDeviceToHost);

        // Verify results
        for (int i = 0; i < count; i++) {
            float actual = __half2float(h_result[i]);
            if (!almostEqual(actual, h_expected[i], FP16_EPSILON)) {
                cudaFree(d_input);
                cudaFree(d_result);
                return TestReport("runScalarMultiplyFP16", FAIL,
                    "Result mismatch at index " + std::to_string(i) +
                    " Expected: " + std::to_string(h_expected[i]) +
                    " Actual: " + std::to_string(actual));
            }
        }

        cudaFree(d_input);
        cudaFree(d_result);
        return TestReport("runScalarMultiplyFP16", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runScalarMultiplyFP16", FAIL, e.what());
    }
}

// ------------------------
// Element-wise Operations Tests
// ------------------------

//TestReport testElementwiseMultiplyFP32() {
//    try {
//        const int count = 1024;
//        std::vector<float> h_A(count);
//        std::vector<float> h_B(count);
//        std::vector<float> h_C(count);
//        std::vector<float> h_expected(count);
//
//        // Generate test data
//        for (int i = 0; i < count; i++) {
//            h_A[i] = float_dist(rng);
//            h_B[i] = float_dist(rng);
//            h_expected[i] = h_A[i] * h_B[i];
//        }
//
//        // Allocate GPU memory
//        float *d_A, *d_B, *d_C;
//        cudaMalloc(&d_A, count * sizeof(float));
//        cudaMalloc(&d_B, count * sizeof(float));
//        cudaMalloc(&d_C, count * sizeof(float));
//
//        // Copy data to GPU
//        cudaMemcpy(d_A, h_A.data(), count * sizeof(float), cudaMemcpyHostToDevice);
//        cudaMemcpy(d_B, h_B.data(), count * sizeof(float), cudaMemcpyHostToDevice);
//
//        // Execute GPU computation
//        runSingleElementTensorMultiplyFP32(d_A, d_B, d_C, count);
//
//        // Copy result back to CPU
//        cudaMemcpy(h_C.data(), d_C, count * sizeof(float), cudaMemcpyDeviceToHost);
//
//        // Verify results
//        for (int i = 0; i < count; i++) {
//            if (!almostEqual(h_C[i], h_expected[i], static_cast<float>(EPSILON))) {
//                cudaFree(d_A);
//                cudaFree(d_B);
//                cudaFree(d_C);
//                return TestReport("runSingleElementTensorMultiplyFP32", FAIL, "Result mismatch");
//            }
//        }
//
//        cudaFree(d_A);
//        cudaFree(d_B);
//        cudaFree(d_C);
//        return TestReport("runSingleElementTensorMultiplyFP32", PASS);
//    }
//    catch (const std::exception& e) {
//        return TestReport("runSingleElementTensorMultiplyFP32", FAIL, e.what());
//    }
//}

// ------------------------
// BF16 Element-wise Multiply Test
// ------------------------

TestReport testSingleElementTensorMultiplyBF16() {
    try {
        const int count = 1024;
        std::vector<bfloat16> h_A(count);
        std::vector<bfloat16> h_B(count);
        std::vector<bfloat16> h_C(count);
        std::vector<float> h_expected(count);

        // Generate test data
        h_B.assign(count, bfloat16(0.0f));
        float valB = float_dist(rng);
        h_B[0] = __float2bfloat16(valB);
        for (int i = 0; i < count; i++) {
            float valA = float_dist(rng);
            h_A[i] = __float2bfloat16(valA);
            h_expected[i] = valA * valB;
        }

        // Allocate GPU memory
        bfloat16* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, count * sizeof(bfloat16));
        cudaMalloc(&d_B, count * sizeof(bfloat16));
        cudaMalloc(&d_C, count * sizeof(bfloat16));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), count * sizeof(bfloat16), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), count * sizeof(bfloat16), cudaMemcpyHostToDevice);

        // Execute GPU computation
        runSingleElementTensorMultiplyBF16(d_A, d_B, d_C, count);

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, count * sizeof(bfloat16), cudaMemcpyDeviceToHost);

        // Verify results with BF16 tolerance
        for (int i = 0; i < count; i++) {
            float actual = __bfloat162float(h_C[i]);
            float expected = h_expected[i];

            if (fabs(expected) < 1e-3) {
                // Near-zero values - check absolute difference
                if (fabs(actual - expected) > BF16_EPSILON) {
                    cudaFree(d_A);
                    cudaFree(d_B);
                    cudaFree(d_C);
                    return TestReport("runSingleElementTensorMultiplyBF16", FAIL,
                        "Result mismatch at index " + std::to_string(i) +
                        " Expected: " + std::to_string(expected) +
                        " Actual: " + std::to_string(actual));
                }
            }
            else {
                // Non-zero values - check relative difference
                if (fabs((actual - expected) / expected) > BF16_EPSILON) {
                    cudaFree(d_A);
                    cudaFree(d_B);
                    cudaFree(d_C);
                    return TestReport("runSingleElementTensorMultiplyBF16", FAIL,
                        "Result mismatch at index " + std::to_string(i) +
                        " Expected: " + std::to_string(expected) +
                        " Actual: " + std::to_string(actual));
                }
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runSingleElementTensorMultiplyBF16", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runSingleElementTensorMultiplyBF16", FAIL, e.what());
    }
}



TestReport testSingleElementTensorMultiplyFP8E4M3() {  // ���²��Ժ�����
    try {
        const int count = 1024;
        std::vector<__nv_fp8_e4m3> h_A(count);
        std::vector<__nv_fp8_e4m3> h_B(count);
        std::vector<__nv_fp8_e4m3> h_C(count);
        std::vector<float> h_expected(count);

        // ��ʼ�������������
        std::random_device rd;
        std::mt19937 rng(rd());
        std::uniform_real_distribution<float> fp8_dist(-2.0f, 2.0f);

        // ʹ��CUDAר��ת������
        auto float_to_fp8_e4m3 = [](float val) {
            return __nv_fp8_e4m3(val);  // ʹ��ר�ú�������static_cast
            };
        auto fp8_e4m3_to_float = [](__nv_fp8_e4m3 val) {
            return static_cast<float>(val);
            };

        // Generate test data
        h_B.assign(count, __nv_fp8_e4m3(0.0f));
        float valB = fp8_dist(rng);
        h_B[0] = float_to_fp8_e4m3(valB);
        for (int i = 0; i < count; i++) {
            float valA = fp8_dist(rng);
            h_A[i] = float_to_fp8_e4m3(valA);
            // ����ֵ���㿼��FP8������ʧ
            h_expected[i] = static_cast<float>(h_A[i]) * valB;
        }

        // Allocate GPU memory
        __nv_fp8_e4m3* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, count * sizeof(__nv_fp8_e4m3));
        cudaMalloc(&d_B, count * sizeof(__nv_fp8_e4m3));
        cudaMalloc(&d_C, count * sizeof(__nv_fp8_e4m3));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), count * sizeof(__nv_fp8_e4m3), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), count * sizeof(__nv_fp8_e4m3), cudaMemcpyHostToDevice);

        // ʹ�ø��º�ĺ�����
        runSingleElementTensorMultiplyFP8E4M3(d_A, d_B, d_C, count);

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, count * sizeof(__nv_fp8_e4m3), cudaMemcpyDeviceToHost);

        // ����ȷ��FP8����
        const float fp8_epsilon = 0.2f;  // �������̶�
        int errors = 0;
        for (int i = 0; i < count; i++) {
            float actual = fp8_e4m3_to_float(h_C[i]);
            float expected = h_expected[i];
            float diff = std::fabs(actual - expected);

            // ����NaN��Inf
            if (std::isnan(actual) || std::isnan(expected)) {
                errors++;
                continue;
                }

            // ͳһʹ�þ��������
            if (diff > fp8_epsilon) {
                errors++;
            }

            // ����һ����������FP8���Ƚϵͣ�
            if (errors > count * 0.1) {  // ����10%�����
                    cudaFree(d_A);
                    cudaFree(d_B);
                    cudaFree(d_C);
                return TestReport("testSingleElementTensorMultiplyFP8E4M3", FAIL,
                        "Result mismatch at index " + std::to_string(i) +
                        " Expected: " + std::to_string(expected) +
                    " Actual: " + std::to_string(actual)+
                    " Too many errors: " + std::to_string(errors) + "/" + std::to_string(count) 
                );
            }

        }
        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runSingleElementTensorMultiplyFP8E4M3", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runSingleElementTensorMultiplyFP8E4M3", FAIL, e.what());
    }
}


// ------------------------
// FP8 E5M2 Element-wise Multiply Test
// ------------------------

TestReport testSingleElementTensorMultiplyFP8E5M2() { 
    try {
        const int count = 1024;
        std::vector<__nv_fp8_e5m2> h_A(count);  // ʹ��CUDAԭ������
        std::vector<__nv_fp8_e5m2> h_B(count);
        std::vector<__nv_fp8_e5m2> h_C(count);
        std::vector<float> h_expected(count);

        // ��ʼ�������������
        std::random_device rd;
        std::mt19937 rng(rd());
        std::uniform_real_distribution<float> fp8_dist(-4.0f, 4.0f);  // ��FP8��Ч��Χ��

        // ����FP8ת�����������δ���壩
        auto float_to_fp8_e5m2 = [](float val) {
            return static_cast<__nv_fp8_e5m2>(val);
            };
        auto fp8_e5m2_to_float = [](__nv_fp8_e5m2 val) {
            return static_cast<float>(val);
            };

        // Generate test data
        h_B.assign(count, __nv_fp8_e5m2(0.0f));
        float valB = fp8_dist(rng);
        h_B[0] = float_to_fp8_e5m2(valB);
        for (int i = 0; i < count; i++) {
            float valA = fp8_dist(rng);
            h_A[i] = float_to_fp8_e5m2(valA);
            h_expected[i] = valA * valB;
        }

        // Allocate GPU memory
        __nv_fp8_e5m2* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, count * sizeof(__nv_fp8_e5m2));
        cudaMalloc(&d_B, count * sizeof(__nv_fp8_e5m2));
        cudaMalloc(&d_C, count * sizeof(__nv_fp8_e5m2));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), count * sizeof(__nv_fp8_e5m2), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), count * sizeof(__nv_fp8_e5m2), cudaMemcpyHostToDevice);

        runSingleElementTensorMultiplyFP8E5M2(d_A, d_B, d_C, count);

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, count * sizeof(__nv_fp8_e5m2), cudaMemcpyDeviceToHost);


        const float fp8_epsilon = 0.2f;  // �������̶�
        int errors = 0;
        for (int i = 0; i < count; i++) {
            float actual = fp8_e5m2_to_float(h_C[i]);
            float expected = h_expected[i];
            float diff = std::fabs(actual - expected);

            // ����NaN��Inf
            if (std::isnan(actual) || std::isnan(expected)) {
                errors++;
                continue;
                }

            // ͳһʹ�þ��������
            if (diff > fp8_epsilon) {
                errors++;
            }
            // ����һ����������FP8���Ƚϵͣ�
            if (errors > count * 0.1) {  // ����10%�����
                    cudaFree(d_A);
                    cudaFree(d_B);
                    cudaFree(d_C);
                    return TestReport("runSingleElementTensorMultiplyFP8E5M2", FAIL,
                        "Result mismatch at index " + std::to_string(i) +
                        " Expected: " + std::to_string(expected) +
                    " Actual: " + std::to_string(actual) +
                    " Too many errors: " + std::to_string(errors) + "/" + std::to_string(count)
                    );
            }

        }
        

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runSingleElementTensorMultiplyFP8E5M2", PASS);  // ���²�����
    }
    catch (const std::exception& e) {
        return TestReport("runSingleElementTensorMultiplyFP8E5M2", FAIL, e.what());  // ���²�����
    }
}

TestReport testAddFP32() {
    try {
        const int count = 1024;
        std::vector<float> h_A(count);
        std::vector<float> h_B(count);
        std::vector<float> h_C(count);
        std::vector<float> h_expected(count);

        // Generate test data
        for (int i = 0; i < count; i++) {
            h_A[i] = float_dist(rng);
            h_B[i] = float_dist(rng);
            h_expected[i] = h_A[i] + h_B[i];
        }

        // Allocate GPU memory
        float *d_A, *d_B, *d_C;
        cudaMalloc(&d_A, count * sizeof(float));
        cudaMalloc(&d_B, count * sizeof(float));
        cudaMalloc(&d_C, count * sizeof(float));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), count * sizeof(float), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), count * sizeof(float), cudaMemcpyHostToDevice);

        // Execute GPU computation
        runAddFP32(d_A, d_B, d_C, count);

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, count * sizeof(float), cudaMemcpyDeviceToHost);

        // Verify results
        for (int i = 0; i < count; i++) {
            if (!almostEqual(h_C[i], h_expected[i], static_cast<float>(EPSILON))) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runAddFP32", FAIL, "Result mismatch");
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runAddFP32", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runAddFP32", FAIL, e.what());
    }
}

TestReport testAddFP64() {
    try {
        const int count = 1024;
        std::vector<double> h_A(count);
        std::vector<double> h_B(count);
        std::vector<double> h_C(count);
        std::vector<double> h_expected(count);

        // Generate test data
        for (int i = 0; i < count; i++) {
            h_A[i] = double_dist(rng);  // ������double_dist�ֲ�
            h_B[i] = double_dist(rng);
            h_expected[i] = h_A[i] + h_B[i];
        }

        // Allocate GPU memory
        double* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, count * sizeof(double));
        cudaMalloc(&d_B, count * sizeof(double));
        cudaMalloc(&d_C, count * sizeof(double));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), count * sizeof(double), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), count * sizeof(double), cudaMemcpyHostToDevice);

        // Execute GPU computation
        runAddFP64(d_A, d_B, d_C, count);  // ������runAddFP64�ں�

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, count * sizeof(double), cudaMemcpyDeviceToHost);

        // Verify results
        for (int i = 0; i < count; i++) {
            if (!almostEqual(h_C[i], h_expected[i], static_cast<double>(EPSILON))) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runAddFP64", FAIL, "Result mismatch");
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runAddFP64", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runAddFP64", FAIL, e.what());
    }
}

TestReport testAddFP16() {
    try {
        const int count = 1024;
        std::vector<__half> h_A(count);
        std::vector<__half> h_B(count);
        std::vector<__half> h_C(count);
        std::vector<float> h_expected(count);  // ʹ��float�洢Ԥ��ֵ�Ա�Ƚ�

        // ���������ȷֲ��������������ɲ�������
        std::uniform_real_distribution<float> float_dist(-1.0f, 1.0f);  // ʹ�ý�С��Χ�������

        // Generate test data
        for (int i = 0; i < count; i++) {
            float a = float_dist(rng);
            float b = float_dist(rng);
            h_A[i] = __float2half(a);
            h_B[i] = __float2half(b);
            h_expected[i] = a + b;  // ��float�����¼���Ԥ�ڽ��
        }

        // Allocate GPU memory
        __half* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, count * sizeof(__half));
        cudaMalloc(&d_B, count * sizeof(__half));
        cudaMalloc(&d_C, count * sizeof(__half));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), count * sizeof(__half), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), count * sizeof(__half), cudaMemcpyHostToDevice);

        // Execute GPU computation
        runAddFP16(d_A, d_B, d_C, count);  // ����FP16�ں�

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, count * sizeof(__half), cudaMemcpyDeviceToHost);

        // Verify results - ת��Ϊfloat���бȽ�
        const float epsilon = 1e-3f;  // FP16��Ҫ������ݲ�
        for (int i = 0; i < count; i++) {
            float result = __half2float(h_C[i]);
            if (std::fabs(result - h_expected[i]) > epsilon) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runAddFP16", FAIL, "Result mismatch");
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runAddFP16", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runAddFP16", FAIL, e.what());
    }
}

TestReport testScalarAddFP32() {
    try {
        const int count = 1024;
        const float scalar = float_dist(rng);
        std::vector<float> h_input(count);
        std::vector<float> h_result(count);
        std::vector<float> h_expected(count);

        // Generate test data
        for (int i = 0; i < count; i++) {
            h_input[i] = float_dist(rng);
            h_expected[i] = h_input[i] + scalar;
        }

        // Allocate GPU memory
        float *d_input, *d_result;
        cudaMalloc(&d_input, count * sizeof(float));
        cudaMalloc(&d_result, count * sizeof(float));

        // Copy data to GPU
        cudaMemcpy(d_input, h_input.data(), count * sizeof(float), cudaMemcpyHostToDevice);

        // Execute GPU computation
        runScalarAddFP32(d_input, scalar, d_result, count);

        // Copy result back to CPU
        cudaMemcpy(h_result.data(), d_result, count * sizeof(float), cudaMemcpyDeviceToHost);

        // Verify results
        for (int i = 0; i < count; i++) {
            if (!almostEqual(h_result[i], h_expected[i], static_cast<float>(EPSILON))) {
                cudaFree(d_input);
                cudaFree(d_result);
                return TestReport("runScalarAddFP32", FAIL, 
                    "Result mismatch at index " + std::to_string(i) +
                    " Expected: " + std::to_string(h_expected[i]) +
                    " Actual: " + std::to_string(h_result[i]));
            }
        }

        cudaFree(d_input);
        cudaFree(d_result);
        return TestReport("runScalarAddFP32", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runScalarAddFP32", FAIL, e.what());
    }
}

TestReport testMinusFP32() {
    try {
        const int count = 1024;
        std::vector<float> h_A(count);
        std::vector<float> h_B(count);
        std::vector<float> h_C(count);
        std::vector<float> h_expected(count);

        // Generate test data
        for (int i = 0; i < count; i++) {
            h_A[i] = float_dist(rng);
            h_B[i] = float_dist(rng);
            h_expected[i] = h_A[i] - h_B[i];
        }

        // Allocate GPU memory
        float *d_A, *d_B, *d_C;
        cudaMalloc(&d_A, count * sizeof(float));
        cudaMalloc(&d_B, count * sizeof(float));
        cudaMalloc(&d_C, count * sizeof(float));

        // Copy data to GPU
        cudaMemcpy(d_A, h_A.data(), count * sizeof(float), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), count * sizeof(float), cudaMemcpyHostToDevice);

        // Execute GPU computation
        runMinusFP32(d_A, d_B, d_C, count);

        // Copy result back to CPU
        cudaMemcpy(h_C.data(), d_C, count * sizeof(float), cudaMemcpyDeviceToHost);

        // Verify results
        for (int i = 0; i < count; i++) {
            if (!almostEqual(h_C[i], h_expected[i], static_cast<float>(EPSILON))) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runMinusFP32", FAIL, 
                    "Result mismatch at index " + std::to_string(i) +
                    " Expected: " + std::to_string(h_expected[i]) +
                    " Actual: " + std::to_string(h_C[i]));
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runMinusFP32", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runMinusFP32", FAIL, e.what());
    }
}

// ------------------------
// Conversion Tests
// ------------------------

TestReport testConvertFP32ToFP16() {
    try {
        const int count = 1024;
        std::vector<float> h_src(count);
        std::vector<__half> h_dest(count);
        std::vector<__half> h_expected(count);

        // Generate test data
        for (int i = 0; i < count; i++) {
            h_src[i] = float_dist(rng);
            h_expected[i] = __float2half(h_src[i]);
        }

        // Allocate GPU memory
        float *d_src;
        __half *d_dest;
        cudaMalloc(&d_src, count * sizeof(float));
        cudaMalloc(&d_dest, count * sizeof(__half));

        // Copy data to GPU
        cudaMemcpy(d_src, h_src.data(), count * sizeof(float), cudaMemcpyHostToDevice);

        // Execute GPU computation
        runConvertFP32ToFP16(d_src, d_dest, count);

        // Copy result back to CPU
        cudaMemcpy(h_dest.data(), d_dest, count * sizeof(__half), cudaMemcpyDeviceToHost);

        // Verify results
        for (int i = 0; i < count; i++) {
            float expected = __half2float(h_expected[i]);
            float actual = __half2float(h_dest[i]);
            if (!almostEqual(expected, actual, float(FP16_EPSILON))) {
                cudaFree(d_src);
                cudaFree(d_dest);
                return TestReport("runConvertFP32ToFP16", FAIL, 
                    "Result mismatch at index " + std::to_string(i) +
                    " Expected: " + std::to_string(expected) +
                    " Actual: " + std::to_string(actual));
            }
        }

        cudaFree(d_src);
        cudaFree(d_dest);
        return TestReport("runConvertFP32ToFP16", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runConvertFP32ToFP16", FAIL, e.what());
    }
}

TestReport testConvertFP32ToBP16() {
    try {
        const int count = 1024;
        std::vector<float> h_src(count);
        std::vector<bfloat16> h_dest(count);
        std::vector<bfloat16> h_expected(count);

        // ���ɲ�������
        std::uniform_real_distribution<float> float_dist(-100.0f, 100.0f);
        for (int i = 0; i < count; i++) {
            h_src[i] = float_dist(rng);
            h_expected[i] = bfloat16(h_src[i]); // CPU��ת����Ϊ�ο�
        }

        // ����GPU�ڴ�
        float* d_src;
        bfloat16* d_dest;
        cudaMalloc(&d_src, count * sizeof(float));
        cudaMalloc(&d_dest, count * sizeof(bfloat16));

        // �������ݵ�GPU
        cudaMemcpy(d_src, h_src.data(), count * sizeof(float), cudaMemcpyHostToDevice);

        // ִ��GPU����
        runConvertFP32ToBF16(d_src, d_dest, count);

        // ���ƽ����CPU
        cudaMemcpy(h_dest.data(), d_dest, count * sizeof(bfloat16), cudaMemcpyDeviceToHost);

        // ��֤���
        const float epsilon = 1e-3f; // BF16����ԼΪ7λʮ����
        for (int i = 0; i < count; i++) {
            float expected = float(h_expected[i]);
            float actual = float(h_dest[i]);

            // ���⴦��NaN��Inf
            if (std::isnan(expected) && std::isnan(actual)) continue;
            if (std::isinf(expected) && std::isinf(actual) &&
                std::signbit(expected) == std::signbit(actual)) continue;

            // �Ƚ���ֵ
            float diff = std::fabs(expected - actual);
            if (diff > epsilon) {
                cudaFree(d_src);
                cudaFree(d_dest);
                return TestReport("runConvertFP32ToBF16", FAIL,
                    "Result mismatch at index " + std::to_string(i) +
                    " | Expected: " + std::to_string(expected) +
                    " | Actual: " + std::to_string(actual) +
                    " | Source: " + std::to_string(h_src[i]));
            }
        }

        cudaFree(d_src);
        cudaFree(d_dest);
        return TestReport("runConvertFP32ToBF16", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runConvertFP32ToBF16", FAIL, e.what());
    }
}


TestReport testConvertFP16ToFP32() {
    try {
        const int count = 1024;
        std::vector<__half> h_src(count);
        std::vector<float> h_dest(count);
        std::vector<float> h_expected(count);

        // Generate test data
        for (int i = 0; i < count; i++) {
            h_src[i] = __float2half(float_dist(rng));
            h_expected[i] = __half2float(h_src[i]);
        }

        // Allocate GPU memory
        __half *d_src;
        float *d_dest;
        cudaMalloc(&d_src, count * sizeof(__half));
        cudaMalloc(&d_dest, count * sizeof(float));

        // Copy data to GPU
        cudaMemcpy(d_src, h_src.data(), count * sizeof(__half), cudaMemcpyHostToDevice);

        // Execute GPU computation
        runConvertFP16ToFP32(d_src, d_dest, count);

        // Copy result back to CPU
        cudaMemcpy(h_dest.data(), d_dest, count * sizeof(float), cudaMemcpyDeviceToHost);

        // Verify results
        for (int i = 0; i < count; i++) {
            if (!almostEqual(h_dest[i], h_expected[i], static_cast<float>(EPSILON))) {
                cudaFree(d_src);
                cudaFree(d_dest);
                return TestReport("runConvertFP16ToFP32", FAIL, 
                    "Result mismatch at index " + std::to_string(i) +
                    " Expected: " + std::to_string(h_expected[i]) +
                    " Actual: " + std::to_string(h_dest[i]));
            }
        }

        cudaFree(d_src);
        cudaFree(d_dest);
        return TestReport("runConvertFP16ToFP32", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runConvertFP16ToFP32", FAIL, e.what());
    }
}

TestReport testConvertBF16ToFP32() {
    try {
        const int count = 1024;
        std::vector<bfloat16> h_src(count);
        std::vector<float> h_dest(count);
        std::vector<float> h_expected(count);

        // ���ɲ�������
        std::uniform_real_distribution<float> float_dist(-100.0f, 100.0f);
        for (int i = 0; i < count; i++) {
            float src_val = float_dist(rng);
            h_src[i] = bfloat16(src_val);
            h_expected[i] = float(h_src[i]); // CPU��ת����Ϊ�ο�
        }

        // ��������ֵ����
        std::vector<float> specialValues = {
            0.0f, -0.0f, 1.0f, -1.0f,
            std::numeric_limits<float>::infinity(),
            -std::numeric_limits<float>::infinity(),
            std::numeric_limits<float>::quiet_NaN(),
            std::numeric_limits<float>::denorm_min()
        };
        for (int i = 0; i < specialValues.size() && i < 8; i++) {
            h_src[i] = bfloat16(specialValues[i]);
            h_expected[i] = specialValues[i];
        }

        // ����GPU�ڴ�
        bfloat16* d_src;
        float* d_dest;
        cudaMalloc(&d_src, count * sizeof(bfloat16));
        cudaMalloc(&d_dest, count * sizeof(float));

        // �������ݵ�GPU
        cudaMemcpy(d_src, h_src.data(), count * sizeof(bfloat16), cudaMemcpyHostToDevice);

        // ִ��GPU����
        runConvertBF16ToFP32(d_src, d_dest, count);

        // ���ƽ����CPU
        cudaMemcpy(h_dest.data(), d_dest, count * sizeof(float), cudaMemcpyDeviceToHost);

        // ��֤���
        const float epsilon = 1e-7f; // BF16->FP32ת��Ӧ���Ǿ�ȷ��
        for (int i = 0; i < count; i++) {
            float expected = h_expected[i];
            float actual = h_dest[i];

            // ���⴦��NaN
            if (std::isnan(expected) && std::isnan(actual)) continue;

            // �Ƚ���ֵ
            float diff = std::fabs(expected - actual);
            if (diff > epsilon) {
                // ��ԭʼBF16ֵת����float�Ա����
                float src_float = float(h_src[i]);

                cudaFree(d_src);
                cudaFree(d_dest);
                return TestReport("runConvertBF16ToFP32", FAIL,
                    "Result mismatch at index " + std::to_string(i) +
                    " | Expected: " + std::to_string(expected) +
                    " | Actual: " + std::to_string(actual) +
                    " | Source (BF16 as float): " + std::to_string(src_float));
            }
        }

        cudaFree(d_src);
        cudaFree(d_dest);
        return TestReport("runConvertBF16ToFP32", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runConvertBF16ToFP32", FAIL, e.what());
    }
}

// Similar tests for BF16 conversions can be added here
// ------------------------
// Matmul Test Functions
// ------------------------

// FP32����˷�����
TestReport testMatmulFP32() {
    try {
        const int m = 128, n = 128, k = 128;
        std::vector<float> h_A(m * k);
        std::vector<float> h_B(k * n);
        std::vector<float> h_C(m * n);
        std::vector<float> h_expected(m * n);

        // ���ɲ�������
        std::uniform_real_distribution<float> float_dist(-1.0f, 1.0f);
        for (int i = 0; i < m * k; i++) h_A[i] = float_dist(rng);
        for (int i = 0; i < k * n; i++) h_B[i] = float_dist(rng);

        // CPU�˼���Ԥ�ڽ��
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                float sum = 0.0f;
                for (int p = 0; p < k; p++) {
                    sum += h_A[i * k + p] * h_B[p * n + j];
                }
                h_expected[i * n + j] = sum;
            }
        }

        // ����GPU�ڴ�
        float* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, m * k * sizeof(float));
        cudaMalloc(&d_B, k * n * sizeof(float));
        cudaMalloc(&d_C, m * n * sizeof(float));

        // �������ݵ�GPU
        cudaMemcpy(d_A, h_A.data(), m * k * sizeof(float), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), k * n * sizeof(float), cudaMemcpyHostToDevice);

        // ִ��GPU����
        runMatmulFP32(d_A, d_B, d_C, m, n, k);

        // ���ƽ����CPU
        cudaMemcpy(h_C.data(), d_C, m * n * sizeof(float), cudaMemcpyDeviceToHost);

        // ��֤���
        const float epsilon = 1e-4f;
        for (int i = 0; i < m * n; i++) {
            if (std::fabs(h_C[i] - h_expected[i]) > epsilon) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runMatmulFP32", FAIL, "Result mismatch");
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runMatmulFP32", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runMatmulFP32", FAIL, e.what());
    }
}

// FP16����˷�����
TestReport testMatmulFP16() {
    try {
        const int m = 128, n = 128, k = 128;
        std::vector<__half> h_A(m * k);
        std::vector<__half> h_B(k * n);
        std::vector<__half> h_C(m * n);
        std::vector<float> h_expected(m * n);

        // ���ɲ�������
        std::uniform_real_distribution<float> float_dist(-1.0f, 1.0f);
        for (int i = 0; i < m * k; i++)
            h_A[i] = __float2half_rn(float_dist(rng));
        for (int i = 0; i < k * n; i++)
            h_B[i] = __float2half_rn(float_dist(rng));

        // CPU�˼���Ԥ�ڽ����ʹ��float���ȣ�
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                float sum = 0.0f;
                for (int p = 0; p < k; p++) {
                    float a = __half2float(h_A[i * k + p]);
                    float b = __half2float(h_B[p * n + j]);
                    sum += a * b;
                }
                h_expected[i * n + j] = sum;
            }
        }

        // ����GPU�ڴ�
        __half* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, m * k * sizeof(__half));
        cudaMalloc(&d_B, k * n * sizeof(__half));
        cudaMalloc(&d_C, m * n * sizeof(__half));

        // �������ݵ�GPU
        cudaMemcpy(d_A, h_A.data(), m * k * sizeof(__half), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), k * n * sizeof(__half), cudaMemcpyHostToDevice);

        // ִ��GPU����
        runMatmulFP16(d_A, d_B, d_C, m, n, k);

        // ���ƽ����CPU
        cudaMemcpy(h_C.data(), d_C, m * n * sizeof(__half), cudaMemcpyDeviceToHost);

        // ��֤�����ת��Ϊfloat�Ƚϣ�
        const float epsilon = 1e-2f;  // FP16��Ҫ������ݲ�
        for (int i = 0; i < m * n; i++) {
            float result = __half2float(h_C[i]);
            if (std::fabs(result - h_expected[i]) > epsilon) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runMatmulFP16", FAIL, 
                    "Result mismatch at index " + std::to_string(i) +
                    " Expected: " + std::to_string(h_expected[i]) +
                    " Actual: " + std::to_string(result));
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runMatmulFP16", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runMatmulFP16", FAIL, e.what());
    }
}

// BF16����˷�����
TestReport testMatmulBF16() {
    try {
        const int m = 128, n = 128, k = 128;
        std::vector<bfloat16> h_A(m * k);
        std::vector<bfloat16> h_B(k * n);
        std::vector<bfloat16> h_C(m * n);
        std::vector<float> h_expected(m * n);

        // ���ɲ�������
        std::uniform_real_distribution<float> float_dist(-1.0f, 1.0f);
        for (int i = 0; i < m * k; i++)
            h_A[i] = bfloat16(float_dist(rng));
        for (int i = 0; i < k * n; i++)
            h_B[i] = bfloat16(float_dist(rng));

        // CPU�˼���Ԥ�ڽ����ʹ��float���ȣ�
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                float sum = 0.0f;
                for (int p = 0; p < k; p++) {
                    float a = float(h_A[i * k + p]);
                    float b = float(h_B[p * n + j]);
                    sum += a * b;
                }
                h_expected[i * n + j] = sum;
            }
        }

        // ����GPU�ڴ�
        bfloat16* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, m * k * sizeof(bfloat16));
        cudaMalloc(&d_B, k * n * sizeof(bfloat16));
        cudaMalloc(&d_C, m * n * sizeof(bfloat16));

        // �������ݵ�GPU
        cudaMemcpy(d_A, h_A.data(), m * k * sizeof(bfloat16), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), k * n * sizeof(bfloat16), cudaMemcpyHostToDevice);

        // ִ��GPU����
        runMatmulBF16(d_A, d_B, d_C, m, n, k);

        // ���ƽ����CPU
        cudaMemcpy(h_C.data(), d_C, m * n * sizeof(bfloat16), cudaMemcpyDeviceToHost);

        // ��֤�����ת��Ϊfloat�Ƚϣ�
        const float epsilon = 1e-2f;  // BF16��������FP16
        for (int i = 0; i < m * n; i++) {
            float result = float(h_C[i]);
            if (std::fabs(result - h_expected[i]) > epsilon) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runMatmulBF16", FAIL, 
                    "Result mismatch at index " + std::to_string(i) +
                    " Expected: " + std::to_string(h_expected[i]) +
                    " Actual: " + std::to_string(result));
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runMatmulBF16", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runMatmulBF16", FAIL, e.what());
    }
}

// FP8 E4M3����˷�����
TestReport testMatmulFP8E4M3() {
    try {
        const int m = 64, n = 64, k = 64;  // ʹ�ý�С����������
        std::vector<fp8_e4m3> h_A(m * k);
        std::vector<fp8_e4m3> h_B(k * n);
        std::vector<fp8_e4m3> h_C(m * n);
        std::vector<float> h_expected(m * n);

        // ���ɲ������ݣ�ʹ�ý�С��Χ��
        std::uniform_real_distribution<float> float_dist(-0.5f, 0.5f);
        for (int i = 0; i < m * k; i++)
            h_A[i] = float_to_fp8_e4m3(float_dist(rng));
        for (int i = 0; i < k * n; i++)
            h_B[i] = float_to_fp8_e4m3(float_dist(rng));

        // CPU�˼���Ԥ�ڽ����ʹ��float���ȣ�
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                float sum = 0.0f;
                for (int p = 0; p < k; p++) {
                    float a = fp8_e4m3_to_float(h_A[i * k + p]);
                    float b = fp8_e4m3_to_float(h_B[p * n + j]);
                    sum += a * b;
                }
                h_expected[i * n + j] = sum;
            }
        }

        // ����GPU�ڴ�
        fp8_e4m3* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, m * k * sizeof(fp8_e4m3));
        cudaMalloc(&d_B, k * n * sizeof(fp8_e4m3));
        cudaMalloc(&d_C, m * n * sizeof(fp8_e4m3));

        // �������ݵ�GPU
        cudaMemcpy(d_A, h_A.data(), m * k * sizeof(fp8_e4m3), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), k * n * sizeof(fp8_e4m3), cudaMemcpyHostToDevice);

        // ִ��GPU����
        runMatmulFP8E4M3(d_A, d_B, d_C, m, n, k);

        // ���ƽ����CPU
        cudaMemcpy(h_C.data(), d_C, m * n * sizeof(fp8_e4m3), cudaMemcpyDeviceToHost);

        // ��֤�����ת��Ϊfloat�Ƚϣ�
        const float epsilon = 1e-1f;  // FP8��Ҫ������ݲ�
        for (int i = 0; i < m * n; i++) {
            float result = fp8_e4m3_to_float(h_C[i]);
            if (std::fabs(result - h_expected[i]) > epsilon) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runMatmulFP8E4M3", FAIL, 
                    "Result mismatch at index " + std::to_string(i) +
                    " Expected: " + std::to_string(h_expected[i]) +
                    " Actual: " + std::to_string(result));
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runMatmulFP8E4M3", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runMatmulFP8E4M3", FAIL, e.what());
    }
}

// FP8 E5M2����˷�����
TestReport testMatmulFP8E5M2() {
    try {
        const int m = 64, n = 64, k = 64;  // ʹ�ý�С����������
        std::vector<fp8_e5m2> h_A(m * k);
        std::vector<fp8_e5m2> h_B(k * n);
        std::vector<fp8_e5m2> h_C(m * n);
        std::vector<float> h_expected(m * n);

        // ���ɲ������ݣ�ʹ�ý�С��Χ��
        std::uniform_real_distribution<float> float_dist(-0.5f, 0.5f);
        for (int i = 0; i < m * k; i++)
            h_A[i] = float_to_fp8_e5m2(float_dist(rng));
        for (int i = 0; i < k * n; i++)
            h_B[i] = float_to_fp8_e5m2(float_dist(rng));

        // CPU�˼���Ԥ�ڽ����ʹ��float���ȣ�
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                float sum = 0.0f;
                for (int p = 0; p < k; p++) {
                    float a = fp8_e5m2_to_float(h_A[i * k + p]);
                    float b = fp8_e5m2_to_float(h_B[p * n + j]);
                    sum += a * b;
                }
                h_expected[i * n + j] = sum;
            }
        }

        // ����GPU�ڴ�
        fp8_e5m2* d_A, * d_B, * d_C;
        cudaMalloc(&d_A, m * k * sizeof(fp8_e5m2));
        cudaMalloc(&d_B, k * n * sizeof(fp8_e5m2));
        cudaMalloc(&d_C, m * n * sizeof(fp8_e5m2));

        // �������ݵ�GPU
        cudaMemcpy(d_A, h_A.data(), m * k * sizeof(fp8_e5m2), cudaMemcpyHostToDevice);
        cudaMemcpy(d_B, h_B.data(), k * n * sizeof(fp8_e5m2), cudaMemcpyHostToDevice);

        // ִ��GPU����
        runMatmulFP8E5M2(d_A, d_B, d_C, m, n, k);

        // ���ƽ����CPU
        cudaMemcpy(h_C.data(), d_C, m * n * sizeof(fp8_e5m2), cudaMemcpyDeviceToHost);

        // ��֤�����ת��Ϊfloat�Ƚϣ�
        const float epsilon = 1e-1f;  // FP8��Ҫ������ݲ�
        for (int i = 0; i < m * n; i++) {
            float result = fp8_e5m2_to_float(h_C[i]);
            if (std::fabs(result - h_expected[i]) > epsilon) {
                cudaFree(d_A);
                cudaFree(d_B);
                cudaFree(d_C);
                return TestReport("runMatmulFP8E5M2", FAIL, 
                    "Result mismatch at index " + std::to_string(i) +
                    " Expected: " + std::to_string(h_expected[i]) +
                    " Actual: " + std::to_string(result));
            }
        }

        cudaFree(d_A);
        cudaFree(d_B);
        cudaFree(d_C);
        return TestReport("runMatmulFP8E5M2", PASS);
    }
    catch (const std::exception& e) {
        return TestReport("runMatmulFP8E5M2", FAIL, e.what());
    }
}


// ------------------------
// Main Test Function
// ------------------------

int main() {
    std::cout << "=== GARNET CUDA TEST START ===" << std::endl;

    // Memory Management Tests
    printTestReport(testZeroInitializeFP32());
    printTestReport(testZeroInitializeFP16());
    printTestReport(testZeroInitializeBF16());

    // GEMM Tests
    printTestReport(testGemmFP32());
    printTestReport(testGemmFP16());
    printTestReport(testGemmBF16());
    // FP8 GEMM Tests
    printTestReport(testGemmFP8E4M3());
    printTestReport(testGemmFP8E5M2());

    // Single Element Tensor Multiply Tests
    printTestReport(testSingleElementTensorMultiplyFP32());
    printTestReport(testSingleElementTensorMultiplyFP16());
//    printTestReport(testElementwiseMultiplyFP32());
    printTestReport(testSingleElementTensorMultiplyBF16());
    printTestReport(testSingleElementTensorMultiplyFP8E4M3());
    printTestReport(testSingleElementTensorMultiplyFP8E5M2());

    // Scalar Multiply Tests
    printTestReport(testScalarMultiplyFP32());
    printTestReport(testScalarMultiplyFP16());

    // Element-wise Operations Tests
    printTestReport(testAddFP64());
    printTestReport(testAddFP32());
    printTestReport(testAddFP16());
    printTestReport(testScalarAddFP32());
    printTestReport(testMinusFP32());
    // Add tests for FP16, BF16 versions here

    // Conversion Tests
    printTestReport(testConvertFP32ToFP16());
    printTestReport(testConvertFP32ToBP16());
    printTestReport(testConvertFP16ToFP32());
    printTestReport(testConvertBF16ToFP32());
    // Add tests for other conversions here
    printTestReport(testMatmulFP32());
    printTestReport(testMatmulFP16());
    printTestReport(testMatmulBF16());
    printTestReport(testMatmulFP8E4M3());
    printTestReport(testMatmulFP8E5M2());


    std::cout << "=== GARNET CUDA TEST FINISH ===" << std::endl;
    return 0;
}